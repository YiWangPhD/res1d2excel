#!/usr/bin/env python
# coding: utf-8

# Author: copilot 
# Supervisor: Yi Wang

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Iterator, List, Optional, Union
import pandas as pd
import os
import warnings
import math

from .base_element import BaseElement
from . import combined_element
from . import diagnostics
from . import simple_element


ElementDataFrames = Dict[str, pd.DataFrame]
CombinedItem = Dict[str, Any]
AliasLookup = Dict[str, Dict[str, BaseElement]]


@dataclass
class ColumnMatch:
    column: Optional[Union[str, tuple[str, float]]] = None
    reason: Optional[str] = None
    available_columns: Optional[list[Any]] = None
    available_simple_columns: Optional[list[Any]] = None
    available_tuple_columns: Optional[list[Any]] = None
    available_element_ids: Optional[list[Any]] = None
    available_chainages: Optional[list[Any]] = None
    selected_chainage: Any = None


class ElementCollection:
    
    CHAINAGE_LAST: int = -1

    def __init__(self, element_type: str) -> None:
        self._element_type: str = element_type
        # quantity_id -> {element: element}
        self._quantities: Dict[str, Dict[BaseElement, BaseElement]] = {}

    # -------------------------
    # Element management
    # -------------------------

    def add_element(self, element: BaseElement) -> None:
        if not isinstance(element, BaseElement):
            raise TypeError("element must be BaseElement")

        if element.get_element_type() != self._element_type:
            raise ValueError("Element type mismatch")

        quantity_id = element.get_quantity_id()

        if quantity_id not in self._quantities:
            self._quantities[quantity_id] = {}

        self._quantities[quantity_id][element] = element

    def get_element_type(self) -> str:
        return self._element_type

    # -------------------------
    # Query - IDs
    # -------------------------

    def get_all_element_ids(self) -> List[str]:
        ids: set[str] = set()

        for elements in self._quantities.values():
            ids.update(e.get_element_id() for e in elements.values())

        return sorted(ids)

    def get_element_ids_by_quantity(self, quantity_id: str) -> List[str]:
        elements = self._quantities.get(quantity_id, {})
        return sorted(set(e.get_element_id() for e in elements.values()))

    # -------------------------
    # Query - elements
    # -------------------------

    def get_all_elements(self) -> List[BaseElement]:
        result: List[BaseElement] = []
        for elements in self._quantities.values():
            result.extend(elements.values())
        return result

    def get_elements_by_quantity(self, quantity_id: str) -> List[BaseElement]:
        return list(self._quantities.get(quantity_id, {}).values())

    def get_elements_by_quantity_and_id(
        self,
        quantity_id: str,
        element_id: str
    ) -> List[BaseElement]:

        return [
            e for e in self.get_elements_by_quantity(quantity_id)
            if e.get_element_id() == element_id
        ]

    def get_quantity_ids(self) -> List[str]:
        return list(self._quantities.keys())
        
    def iter_elements(self) -> Iterator[BaseElement]:
        for elements in self._quantities.values():
            yield from elements.values()
            
    def __len__(self) -> int:
        return sum(len(e) for e in self._quantities.values())

    # -------------------------
    # Factory methods
    # -------------------------

    @classmethod
    def create_simple_collections_from_dataframes(
        cls,
        dfs: ElementDataFrames
    ) -> List["ElementCollection"]:
        element_collections: List[ElementCollection] = []

        for element_type, element_df in dfs.items():
            element_collections.append(
                cls.create_simple_collection_from_dataframe(
                    element_type,
                    element_df
                )
            )

        return element_collections

    @classmethod
    def create_simple_collection_from_dataframe(
        cls,
        element_type: str,
        element_df: pd.DataFrame
    ) -> "ElementCollection":
        collection = cls(element_type)

        if element_df.empty:
            return collection

        for _, row in element_df.iterrows():
            collection.add_element(cls._row_to_simple_element(element_type, row))

        return collection

    @classmethod
    def create_combined_collection(
        cls,
        combined: List[CombinedItem],
        element_collections: List["ElementCollection"],
        discharge_quantities: Iterable[str]
    ) -> "ElementCollection":
        combined_collection = cls("combined")
        if not combined:
            return combined_collection

        alias_lookup = cls._create_element_alias_lookup(element_collections)

        for item in combined:
            alias = item.get("alias")
            if not alias:
                raise ValueError("Combined item missing alias")
            if combined_collection.get_elements_by_quantity_and_id(
                    combined_element.CALCULATED_DISCHARGE,
                    alias):
                raise ValueError(f"Duplicate combined alias: {alias}")
            if not item.get("terms"):
                raise ValueError(f"Combined element '{alias}' has no terms")

            element = combined_element.CombinedElement(alias)
            seen_terms: set[tuple[str, Optional[str]]] = set()

            for term in item.get("terms", []):
                source = term.get("source", "").lower()
                term_alias = term.get("alias")
                op = term.get("op", "+")
                term_key = (source, term_alias)

                if term_key in seen_terms:
                    warnings.warn(
                        f"Combined element '{alias}': duplicate term "
                        f"{source}.{term_alias} ignored"
                    )
                    continue
                seen_terms.add(term_key)

                source_element = cls._get_combined_source_element(
                    alias_lookup,
                    source,
                    term_alias,
                    discharge_quantities
                )
                sign = 1 if op != "-" else -1
                element.add_element(source_element, sign)

            combined_collection.add_element(element)

        return combined_collection

    # -------------------------
    # Add time series (only for SimpleElement)
    # -------------------------

    def add_ts(self, dfs: Dict[str, pd.DataFrame], filename: str) -> None:
        """
        add time series from raw dataframes.
        Only applicable to elements that support external data injection.
        """

        if not isinstance(dfs, dict):
            raise TypeError("dfs must be a dict")

        if not filename:
            raise ValueError("filename must be provided")

        for quantity_id, elements in self._quantities.items():
            df = dfs.get(quantity_id)

            if df is None:
                for element in elements.values():
                    self._warn_no_timeseries(
                        element,
                        filename,
                        f"quantity '{quantity_id}' was not returned",
                    )
                continue

            if not isinstance(df, pd.DataFrame):
                raise TypeError(f"{quantity_id} must map to a DataFrame")

            for element in elements.values():
                match = self._find_column_in_dataframe(element, df)

                if match.column is not None:
                    element.add_ts(filename, df[match.column])

                if element.get_ts(filename) is None:
                    self._warn_no_timeseries(
                        element,
                        filename,
                        match.reason or "no matching dataframe column found",
                        match,
                    )

    # -------------------------
    # Update derived elements (CombinedElement)
    # -------------------------

    def update_ts(self) -> None:
        """
        Call update_ts() for combined elements that compute their own time series.
        """

        for element in self.get_all_elements():
            element.update_ts()

    # -------------------------
    # Statistics
    # -------------------------

    def update_statistics(self, calculator: Optional[Any] = None) -> None:
        for element in self.get_all_elements():
            element.update_statistics(calculator)

    # -------------------------
    # String
    # -------------------------

    def __str__(self) -> str:
        str1 = 'Element type: ' + self._element_type + os.linesep
        for element in self.get_all_elements():
            str1 += str(element) + os.linesep
        return str1

    def __repr__(self) -> str:
        return f"<ElementCollection type={self._element_type}, quantities={len(self._quantities)}>"

    # -------------------------
    # Internal helpers
    # -------------------------

    def _find_column_in_dataframe(
        self,
        element: BaseElement,
        df: pd.DataFrame
    ) -> ColumnMatch:

        cols = df.columns

        element_id = element.get_element_id()
        element_chainage = element.get_chainage()

        if len(cols) == 0:
            return ColumnMatch(
                reason="extracted dataframe has no columns",
                available_columns=[],
            )

        if not isinstance(cols, pd.MultiIndex):
            return self._find_column_in_index(element, cols)

        return self._find_column_in_multiindex(element, cols, df)

    def _find_column_in_index(
        self,
        element: BaseElement,
        cols: pd.Index,
    ) -> ColumnMatch:
        element_id = element.get_element_id()
        tuple_columns = self._tuple_columns(cols)
        simple_columns = [col for col in cols if not isinstance(col, tuple)]

        tuple_match = self._find_tuple_column(element, tuple_columns)
        simple_column = self._find_id_column(simple_columns, element_id)
        simple_match = (
            ColumnMatch(column=simple_column)
            if simple_column is not None else None
        )

        if element.get_element_type() in {"link", "regulation"}:
            if tuple_match.column is not None:
                return tuple_match
            if simple_match is not None:
                return simple_match
        else:
            if simple_match is not None:
                return simple_match
            if tuple_match.column is not None:
                return tuple_match

        if tuple_match.reason is not None:
            return tuple_match

        return ColumnMatch(
            reason=f"element id '{element_id}' was not found in dataframe columns",
            available_simple_columns=simple_columns,
            available_tuple_columns=tuple_columns,
            available_element_ids=self._unique_values(
                col[0] for col in tuple_columns
            ),
        )

    def _find_column_in_multiindex(
        self,
        element: BaseElement,
        cols: pd.MultiIndex,
        df: pd.DataFrame,
    ) -> ColumnMatch:
        if cols.nlevels != 2:
            raise ValueError(
                "MultiIndex dataframe columns must have exactly 2 levels "
                f"(muid, chainage). Found {cols.nlevels} levels."
            )

        element_id = element.get_element_id()
        level0 = cols.get_level_values(0)
        if not self._column_contains_id(level0, element_id):
            return ColumnMatch(
                reason=(
                    f"element id '{element_id}' was not found in dataframe "
                    "column level 'muid'"
                ),
                available_element_ids=self._unique_values(level0),
            )

        matched_level0 = next(
            value for value in level0
            if self._ids_equal(value, element_id)
        )

        sub_df = df[matched_level0]
        chainages = sub_df.columns
        if len(chainages) == 0:
            return ColumnMatch(
                reason=(
                    f"element id '{element_id}' was found, but no chainage "
                    "columns were available"
                ),
                available_element_ids=self._unique_values(level0),
                available_chainages=[],
            )

        return self._match_chainage_to_column(
            element,
            [(matched_level0, chainage) for chainage in chainages],
            available_element_ids=self._unique_values(level0),
        )

    def _find_tuple_column(
        self,
        element: BaseElement,
        tuple_columns: list[tuple[Any, ...]],
    ) -> ColumnMatch:
        if not tuple_columns:
            return ColumnMatch()

        element_id = element.get_element_id()
        matches = [
            col for col in tuple_columns
            if self._ids_equal(col[0], element_id)
        ]
        if not matches:
            return ColumnMatch()

        return self._match_chainage_to_column(
            element,
            matches,
            available_element_ids=self._unique_values(
                col[0] for col in tuple_columns
            ),
            available_tuple_columns=tuple_columns,
        )

    def _match_chainage_to_column(
        self,
        element: BaseElement,
        columns: list[tuple[Any, Any]],
        available_element_ids: Optional[list[Any]] = None,
        available_tuple_columns: Optional[list[Any]] = None,
    ) -> ColumnMatch:
        element_chainage = element.get_chainage()
        chainages = [col[1] for col in columns]

        if len(chainages) == 0:
            return ColumnMatch(
                reason=(
                    f"element id '{element.get_element_id()}' was found, "
                    "but no chainage columns were available"
                ),
                available_element_ids=available_element_ids,
                available_tuple_columns=available_tuple_columns,
                available_chainages=[],
            )

        if element_chainage == self.CHAINAGE_LAST:
            selected = columns[-1]
            return ColumnMatch(
                column=selected,
                available_element_ids=available_element_ids,
                available_tuple_columns=available_tuple_columns,
                available_chainages=chainages,
                selected_chainage=selected[1],
            )

        try:
            selected = min(
                columns,
                key=lambda col: abs(float(col[1]) - float(element_chainage)),
            )
        except (TypeError, ValueError) as exc:
            return ColumnMatch(
                reason=(
                    f"could not match requested chainage {element_chainage} "
                    "against available chainages"
                ),
                available_element_ids=available_element_ids,
                available_tuple_columns=available_tuple_columns,
                available_chainages=chainages,
            )
        closest = selected[1]
        if not self._chainages_equal(element_chainage, closest):
            details = ""
            if diagnostics.is_debug():
                details = (
                    " Available chainages: "
                    f"{diagnostics.format_values(chainages)}."
                )
            warnings.warn(
                f"{self._format_element_for_warning(element)} requested "
                f"chainage {element_chainage}; using nearest available "
                f"chainage {closest}.{details}",
                stacklevel=3,
            )
        return ColumnMatch(
            column=selected,
            available_element_ids=available_element_ids,
            available_tuple_columns=available_tuple_columns,
            available_chainages=chainages,
            selected_chainage=closest,
        )

    @staticmethod
    def _row_to_simple_element(
        element_type: str,
        row: pd.Series
    ) -> simple_element.SimpleElement:
        alias = row.get("alias")
        if ElementCollection._is_missing_value(alias):
            alias = None

        quantity = row.get("quantity")
        muid = str(row.get("muid"))
        chainage = row.get("chainage", 0.0)
        if ElementCollection._is_missing_value(chainage):
            if element_type in {"link", "regulation"}:
                warnings.warn(
                    f"{element_type} element '{muid}' quantity "
                    f"'{quantity}' has blank chainage; using 0.0 for "
                    "nearest-chainage matching.",
                    stacklevel=2,
                )
            chainage = 0.0

        return simple_element.SimpleElement(
            muid,
            alias,
            element_type,
            quantity,
            chainage
        )

    @staticmethod
    def _create_element_alias_lookup(
        element_collections: Iterable["ElementCollection"]
    ) -> AliasLookup:
        alias_lookup: AliasLookup = {}

        for collection in element_collections:
            source = collection.get_element_type().lower()
            alias_lookup[source] = {}

            for element in collection.get_all_elements():
                alias = element.get_element_alias()
                if not alias:
                    continue
                if alias in alias_lookup[source]:
                    raise ValueError(f"Duplicate alias in {source}: {alias}")
                alias_lookup[source][alias] = element

        return alias_lookup

    @staticmethod
    def _get_combined_source_element(
        alias_lookup: AliasLookup,
        source: str,
        alias: Optional[str],
        discharge_quantities: Iterable[str]
    ) -> BaseElement:
        if source not in alias_lookup:
            raise ValueError(f"Invalid combined source: {source}")

        if not alias or alias not in alias_lookup[source]:
            raise ValueError(f"Combined alias not found: {source}.{alias}")

        element = alias_lookup[source][alias]
        if element.get_quantity_id() not in discharge_quantities:
            raise ValueError(f"{source}.{alias} is not a discharge-like quantity")

        return element

    @staticmethod
    def _chainages_equal(left: Any, right: Any) -> bool:
        try:
            return math.isclose(float(left), float(right))
        except (TypeError, ValueError):
            return left == right

    @staticmethod
    def _format_element_for_warning(element: BaseElement) -> str:
        return (
            f"{element.get_element_type()} element "
            f"'{element.get_element_id()}' quantity "
            f"'{element.get_quantity_id()}'"
        )

    @staticmethod
    def _is_missing_value(value: Any) -> bool:
        try:
            return bool(pd.isna(value))
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _unique_values(values: Iterable[Any]) -> list[Any]:
        items = list(dict.fromkeys(values))
        return sorted(items, key=lambda item: str(item))

    @staticmethod
    def _ids_equal(left: Any, right: Any) -> bool:
        return str(left).strip() == str(right).strip()

    @staticmethod
    def _column_contains_id(columns: Iterable[Any], element_id: Any) -> bool:
        return any(
            ElementCollection._ids_equal(column, element_id)
            for column in columns
        )

    @staticmethod
    def _find_id_column(columns: Iterable[Any], element_id: Any) -> Any:
        for column in columns:
            if ElementCollection._ids_equal(column, element_id):
                return column
        return None

    @staticmethod
    def _tuple_columns(cols: pd.Index) -> list[tuple[Any, ...]]:
        tuple_columns = [col for col in cols if isinstance(col, tuple)]
        invalid_columns = [
            col for col in tuple_columns
            if len(col) != 2
        ]
        if invalid_columns:
            raise ValueError(
                "Tuple dataframe columns must have exactly 2 values "
                "(muid, chainage). Invalid columns: "
                f"{diagnostics.format_values(invalid_columns)}"
            )
        return tuple_columns

    @staticmethod
    def _warn_no_timeseries(
        element: BaseElement,
        filename: str,
        reason: str,
        match: ColumnMatch | None = None,
    ) -> None:
        message = (
            "No timeseries assigned to "
            f"{ElementCollection._format_element_for_warning(element)} "
            f"from result file '{filename}': {reason}."
        )
        if diagnostics.is_debug() and match is not None:
            debug_parts = []
            if match.available_columns is not None:
                debug_parts.append(
                    "Available columns: "
                    f"{diagnostics.format_values(match.available_columns)}"
                )
            if match.available_simple_columns is not None:
                debug_parts.append(
                    "Available simple columns: "
                    f"{diagnostics.format_values(match.available_simple_columns)}"
                )
            if match.available_tuple_columns is not None:
                debug_parts.append(
                    "Available tuple columns: "
                    f"{diagnostics.format_values(match.available_tuple_columns)}"
                )
            if match.available_element_ids is not None:
                debug_parts.append(
                    "Available MUIDs: "
                    f"{diagnostics.format_values(match.available_element_ids)}"
                )
            if match.available_chainages is not None:
                debug_parts.append(
                    "Available chainages: "
                    f"{diagnostics.format_values(match.available_chainages)}"
                )
            if debug_parts:
                message += " " + " ".join(debug_parts)
        elif not diagnostics.is_debug():
            message += " Run with --debug for dataframe column details."

        warnings.warn(message, stacklevel=2)
