# -*- coding: utf-8 -*-
# Author: Yi Wang
# this module build input collections/dictionaries using input dataframes


import os
import pandas as pd
from typing import Dict, List, Any
from . import element_collection


COMBINED_QUANTITY = "CalculatedDischarge"
VALID_RESULT_TYPES = {"network", "runoff"}

RESAMPLE_UNIT_ALIASES = {
    "d": "D",
    "day": "D",
    "days": "D",
    "h": "h",
    "hr": "h",
    "hour": "h",
    "hours": "h",
    "min": "min",
    "minute": "min",
    "minutes": "min",
    "s": "s",
    "sec": "s",
    "second": "s",
    "seconds": "s",
}


# create dataframe templates
def create_element_collections_dataframes_template():
    dfs = {}
    dfs['catchment'] = pd.DataFrame({
        'alias': ['S21201401_TotalRunOff', 'S15155401_TotalRunOff', 
                  'S17171302_TotalRunOff', None, 
                  None, 'S17171302_NetRainfall'],
        'quantity':['TotalRunOff', 'TotalRunOff', 'TotalRunOff', 
                    'NetRainfall', 'NetRainfall', 'NetRainfall'],
        'muid':['S21201401', 'S15155401', 'S17171302',
                'S21201401', 'S15155401', 'S17171302']
        })
    dfs['node'] = pd.DataFrame({
        'alias': ['C14150801_WaterLevel', 'C16169801_WaterLevel', None],
        'quantity': ['WaterLevel', 'WaterLevel', 'WaterLevel'],
        'muid': ['C14150801', 'C16169801', 'Inflow to_WWTP_Basin']
        })
    dfs['link'] = pd.DataFrame({
        'alias': ['C15152001.2_WaterLevel', 'C19203901.2_WaterLevel', 
                  None, 'C15152001.2_Discharge', None, 'C20203301.2_Discharge', 
                   'C15152001.2_Velocity', 'C19203901.2_Velocity', None],
        'quantity': ['WaterLevel', 'WaterLevel', 'WaterLevel', 
                     'Discharge', 'Discharge', 'Discharge',
                     'FlowVelocity', 'FlowVelocity', 'FlowVelocity'],
        'muid': ['C15152001.2', 'C19203901.2', 'C20203301.2', 
                 'C15152001.2', 'C19203901.2', 'C20203301.2',
                 'C15152001.2', 'C19203901.2', 'C20203301.2'],
        'chainage': [None, 66.30, 62.965,
                     None, None, 29.75,
                     None, None, None]
        })    
    dfs['orifice'] = pd.DataFrame({
        'alias': ['Sir40.1_O_Discharge', 'Orifice_6_Discharge', 
                  None, 'Sir40.1_O_WaterLevel', 'Orifice_6_WaterLevel', None, 
                  'Sir40.1_O_GateLevel', 'Orifice_6_GateLevel', 
                  'Sir5.1_O_GateLevel', None, None, 'Sir5.1_O_ControlStrategyId'],
        'quantity': ['Discharge', 'Discharge', 'Discharge',
                     'WaterLevel', 'WaterLevel', 'WaterLevel', 
                     'GateLevel', 'GateLevel', 'GateLevel',
                     'ControlStrategyId', 'ControlStrategyId', 
                     'ControlStrategyId'],
        'muid': ['Sir40.1_O', 'Orifice_6', 'Sir5.1_O', 
                 'Sir40.1_O', 'Orifice_6', 'Sir5.1_O', 
                 'Sir40.1_O', 'Orifice_6', 'Sir5.1_O', 
                 'Sir40.1_O', 'Orifice_6', 'Sir5.1_O']
        })    
    dfs['pump'] = pd.DataFrame({
        'alias': ['Pump_1_to_WWTP_Discharge', 'Pump_3_to_WWTP_Discharge', 
                  None, 'Pump_1_to_WWTP_ControlStrategyId', 
                  'Pump_3_to_WWTP_ControlStrategyId', None],
        'quantity': ['Discharge', 'Discharge', 'Discharge',
                     'ControlStrategyId', 'ControlStrategyId', 
                     'ControlStrategyId'],
        'muid': ['Pump_1_to_WWTP', 'Pump_3_to_WWTP', 'SirPump20.1', 
                 'Pump_1_to_WWTP', 'Pump_3_to_WWTP', 'SirPump20.1']
        })    
    dfs['regulation'] = pd.DataFrame({
        'alias': ['C14150801.2_Discharge', 'C14150801.2_WaterLevel', None],
        'quantity': ['Discharge', 'WaterLevel', 'FlowVelocity'],
        'muid': ['C14150801.2', 'C14150801.2', 'C14150801.2'],
        'chainage': [None, None, None]
        })    
    dfs['weir'] = pd.DataFrame({
        'alias': ['Weir_to_WWTP_Discharge', 'Weir_to_river_Discharge',
                  'Weir_to_WWTP_CrestLevel', None, None, None],
        'quantity': ['Discharge', 'Discharge', 
                     'CrestLevel', 'CrestLevel', 
                     'ControlStrategyId', 'ControlStrategyId'],
        'muid': ['Weir_to WWTP', 'Weir_to_river', 
                 'Weir_to WWTP', 'Weir_to_river',  
                 'Weir_to WWTP', 'Weir_to_river']
        })    
    dfs['valve'] = pd.DataFrame({
        'alias': [],
        'quantity': [],
        'muid': []
        })
    dfs['bridge'] = pd.DataFrame({
        'alias': ['Spur_4_Bridge_Discharge'],
        'quantity': ['DischargeInStructure'],
        'muid': ['Spur-4 Bridge']
        })
    dfs['culvert'] = pd.DataFrame({
        'alias': [],
        'quantity': [],
        'muid': []
        })
    dfs['direct_discharge'] = pd.DataFrame({
        'alias': ['Lower_Outlet_East_Discharge'],
        'quantity': ['DischargeInStructure'],
        'muid': ['Lower Outlet East']
        })
    dfs['gate'] = pd.DataFrame({
        'alias': ['Fish_Valve_June_15_ControlStrategyId'],
        'quantity': ['ControlStrategyId'],
        'muid': ['Fish_Valve_June_15']
        })
    return dfs


def create_output_files_dataframe_template():
    output_specifications_df = pd.DataFrame({
        'type': [
            'folder_path', 'resample_t', 'skip_time', 'trunc_time',
            'to_html', 'by_elements', 'by_file', 'stats'
        ],
        'value': [os.getcwd(), '5min', '2h', '6h',
                  True, r"by_element.xlsx", r"by_file.xlsx", r"stats.xlsx"]
        })
    return {'output_files': output_specifications_df}


def create_res1d_files_dataframe_template():
    res1d_files_df = pd.DataFrame({
        'result_type': ['network', 'runoff'],
        'short_name': ['event1', 'event1'],
        'res1d_file_path': [
            r"C:\path\to\network_result.res1d",
            r"C:\path\to\runoff_result.res1d"
        ]
        })
    return {'res1d_files': res1d_files_df}


def create_combined_dataframe_template():
    combined_df = pd.DataFrame({
        'combined_alias': ['Combined1', 'Combined1', 'Combined1', 'Combined1',
                           'Combined1'],
        'quantity': [COMBINED_QUANTITY, COMBINED_QUANTITY,
                     COMBINED_QUANTITY, COMBINED_QUANTITY,
                     COMBINED_QUANTITY],
        'op': ['+', '-', '+', '-', '+'],
        'source': ['link', 'orifice', 'catchment', 'pump',
                   'direct_discharge'],
        'source_alias': ['C15152001.2_Discharge',
                         'Orifice_6_Discharge',
                         'S15155401_TotalRunOff',
                         'Pump_1_to_WWTP_Discharge',
                         'Lower_Outlet_East_Discharge']
        })
    return {'combined': combined_df}


def create_combined_from_dataframe(
        combined_df: pd.DataFrame
        ) -> List[Dict[str, Any]]:
    if combined_df.empty:
        return []

    required_columns = ['combined_alias', 'op', 'source', 'source_alias']
    missing_columns = [
        col for col in required_columns if col not in combined_df.columns
    ]
    if missing_columns:
        raise ValueError(
            f"Combined dataframe missing columns: {', '.join(missing_columns)}"
        )

    combined_df = combined_df.replace("", pd.NA)
    combined = []
    combined_lookup = {}

    for _, row in combined_df.iterrows():
        combined_alias = row.get('combined_alias')
        source = row.get('source')
        source_alias = row.get('source_alias')

        if pd.isna(combined_alias) and pd.isna(source) and pd.isna(source_alias):
            continue

        if pd.isna(combined_alias) or pd.isna(source) or pd.isna(source_alias):
            raise ValueError(
                "Combined rows must include combined_alias, source, "
                "and source_alias"
            )

        combined_alias = str(combined_alias)
        source = str(source)
        source_alias = str(source_alias)

        op = row.get('op', '+')
        if pd.isna(op):
            op = '+'
        op = str(op)

        if combined_alias not in combined_lookup:
            item = {
                'alias': combined_alias,
                'quantity': COMBINED_QUANTITY,
                'terms': []
            }
            combined_lookup[combined_alias] = item
            combined.append(item)

        combined_lookup[combined_alias]['terms'].append({
            'op': op,
            'source': source,
            'alias': source_alias
        })

    return combined


# create collections from dataframes
def create_element_collections_from_dataframes(
        dfs: Dict[str, pd.DataFrame]
        ) -> List[element_collection.ElementCollection]:
    return element_collection.ElementCollection.create_simple_collections_from_dataframes(dfs)


def create_excel_collection_from_dataframes(dfs):
    xlsx_dict = {}
    for sheet_name, sheet_df in dfs.items():
        sheet_df = sheet_df.fillna(0)
        for index, row in sheet_df.iterrows():
            xlsx_dict[row.iloc[0]] = row.iloc[1]
    
    folder_path = xlsx_dict.pop('folder_path')
    to_html = parse_bool(
        xlsx_dict.pop('to_html', xlsx_dict.pop('to html', False))
    )
    if 'resample_t' in xlsx_dict:
        resample_t = xlsx_dict.pop('resample_t')
    else:
        resample_t = None

    if 'skip_time' in xlsx_dict:
        skip_time = xlsx_dict.pop('skip_time')
    else:
        skip_time = None

    if 'trunc_time' in xlsx_dict:
        trunc_time = xlsx_dict.pop('trunc_time')
    else:
        trunc_time = None
        
    if resample_t == 0:
        resample_t = None
    else:
        resample_t = normalize_resample_interval(resample_t)

    if skip_time == 0:
        skip_time = None

    if trunc_time == 0:
        trunc_time = None

    for k, v in xlsx_dict.items():
        xlsx_dict[k] = os.path.join(folder_path, xlsx_dict[k])
        
    xlsx_dict['output_folder'] = folder_path
    xlsx_dict['resample_t'] = resample_t
    xlsx_dict['skip_time'] = skip_time
    xlsx_dict['trunc_time'] = trunc_time
    xlsx_dict['to_html'] = to_html
    
    return xlsx_dict


def normalize_resample_interval(value):
    """
    Convert human-readable durations to pandas resample frequency aliases.
    """
    if value is None or pd.isna(value):
        return None

    if not isinstance(value, str):
        return value

    text = value.strip()
    if not text:
        return None

    parts = text.split()
    if len(parts) != 2:
        return text

    amount, unit = parts
    unit_alias = RESAMPLE_UNIT_ALIASES.get(unit.lower())
    if unit_alias is None:
        return text

    return f"{amount}{unit_alias}"


def parse_bool(value):
    if isinstance(value, bool):
        return value

    if value is None or pd.isna(value):
        return False

    if isinstance(value, str):
        return value.strip().lower() in ['true', 'yes', 'y', '1']

    return bool(value)


def create_res1d_collections_from_dataframes(dfs):
    
    res1d_dict = {}
    for sheet_name, sheet_df in dfs.items():
        for index, row in sheet_df.iterrows():
            result_type = str(row.iloc[0])
            short_name = row.iloc[1]
            res1d_file_path = row.iloc[2]

            if result_type not in VALID_RESULT_TYPES:
                raise ValueError(
                    "Invalid result_type "
                    f"'{result_type}' in res1d_files row {index + 1}. "
                    "Use exactly one of: network, runoff."
                )

            if result_type in res1d_dict:
                res1d_dict[result_type][short_name] = res1d_file_path
            else:
                if result_type in res1d_dict:
                    if short_name in res1d_dict[result_type]:
                        print("Cannot have two files with same short name!")
                        exit()
                    else:
                        res1d_dict[result_type][short_name] = res1d_file_path
                else:
                    res1d_dict[result_type] = {short_name: res1d_file_path}
    return res1d_dict


def main():
    element_collections_dataframes = create_element_collections_dataframes_template()
    element_collections = create_element_collections_from_dataframes(element_collections_dataframes)
    for ec in element_collections:
        print(ec.get_all_element_ids())
    
    res1d_files_dataframe = create_res1d_files_dataframe_template()
    res1d_dict = create_res1d_collections_from_dataframes(res1d_files_dataframe)
    print(res1d_dict)
    
    output_files_dataframe = create_output_files_dataframe_template()
    xlsx_dict = create_excel_collection_from_dataframes(output_files_dataframe)
    print(xlsx_dict)

if __name__ == '__main__':
    main()

